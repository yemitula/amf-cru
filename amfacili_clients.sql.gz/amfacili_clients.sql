-- Adminer 4.0.2 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+01:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `designation` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `influenceRating` int(11) NOT NULL,
  `areaOfInterface` varchar(100) NOT NULL,
  `typeOfService` varchar(100) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `organisation` varchar(100) NOT NULL,
  `buildingNum` varchar(5) NOT NULL,
  `street` varchar(100) NOT NULL,
  `area` varchar(100) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `staff_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `clients` (`id`, `title`, `firstname`, `surname`, `designation`, `level`, `influenceRating`, `areaOfInterface`, `typeOfService`, `email`, `organisation`, `buildingNum`, `street`, `area`, `city`, `state`, `staff_id`) VALUES
(1,	'Mr',	'Tunde',	'Fashola',	'Governor',	'Most Senior Executive',	5,	'End User',	NULL,	'fashola@lagos.gov.ng',	'Lagos State Government',	'1',	'Government Way',	'Alausa',	'Lagos',	'',	1),
(2,	'Engr',	'Femi',	'Akintunde',	'MD/CEO',	'Most Senior Executive',	5,	'Contract Award/Renewal',	NULL,	'femiakintunde@amfacilities.com',	'AMF',	'5',	'Osborne Foreshore Estate',	'Ikoyi',	'Lagos',	'Lagos',	1);

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `staff` (`id`, `name`, `location`, `phone`, `email`, `password`) VALUES
(1,	'John Smith',	'Head Office',	'07013000000',	'johnsmith@amfacilities.com',	'password');

-- 2017-11-02 08:47:44
